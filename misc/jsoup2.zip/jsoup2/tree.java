
import org.jsoup.*;
import org.jsoup.helper.*;
import org.jsoup.nodes.*;
import org.jsoup.parser.*;
import org.jsoup.safety.*;
import org.jsoup.select.*;

import java.io.*;
import java.util.*;

public class tree {
	
	Document doc;

	public tree (String page) {
		try {
			String content = getcontent (page);
			Document doc = Jsoup.parse (content, "", Parser.xmlParser ());
			// just do the body for now
			Elements body = doc.select ("svg");
			for (Element elt : body) {
				String sofar = "";
				describe (sofar, elt);
			}
		}
		catch (Exception e) {
			e.printStackTrace ();
		}
	}

	void show (String s) {
		System.out.println (s);
	}

	String getcontent (String filename) {
		try {
			BufferedReader in = new BufferedReader (new FileReader (filename));
			StringBuffer sb = new StringBuffer ();
			String line;
			while ((line = in.readLine ())!=null) {
				sb.append (line+"\n");
			}
			in.close ();
			String all = new String (sb);
			return all;
		}
		catch (Exception e) {
			e.printStackTrace ();
			return null;
		}
	}

	void describe (String sofar, Element element) {
		try {
			String tag = element.tagName ();
			String id = element.id ();
			String out = id+":"+sofar+":"+tag;
			show (out);
			// if (element.hasText ()) show (element.text ());
			Elements elements = element.children ();
			if (elements.size () > 0) {
				int count = 0;
				for (Element child : elements) {
					String more = sofar+"."+tag+"-"+count;
					count++;
					describe (more, child);
				}
			}
			else {
				if (element.hasText ()) show (element.text ());
			}
		}
		catch (Exception e) {
			e.printStackTrace ();
		}
	}

	void finddata (String test) {
		try {
			StringTokenizer st = new StringTokenizer (test, ".-:");
			String first = st.nextToken ().toLowerCase ();
			Element node = null;
			if (first.equals ("body")) node = doc.body ();
			else if (first.equals ("head")) node = doc.head ();
			int num = Integer.parseInt (st.nextToken ());
			if (node == null) return;
			do {
				Elements children = node.children ();
				if (children.size () > num) {
					Element next = children.get (num);
					if (st.hasMoreTokens ()) {
						String nextag = st.nextToken ();
						if (st.hasMoreTokens ())
						num = Integer.parseInt (st.nextToken ());
						node = next;
					}
				}
				else break;
			} while (st.hasMoreTokens ());
			show ("Search for: "+test);
			if (node.hasText ()) show ("Result: "+node.text ());
			else show ("Node at "+test+" has no text");
		}
		catch (Exception e) {
			e.printStackTrace ();
		}
	}

	public static void main (String args []) {
		String input = "map5.svg";
		tree T = new tree (input);
	}

}

