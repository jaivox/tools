
import java.awt.Point;  // just for storing pairs
import java.awt.Rectangle;
import java.util.*;

public class stats {

	int lsize;
	int local [];
	
    public stats () {
   }

    void Debug (String s) {
        System.out.println (" [stats]" + s);
    }

    Point functionstats (int f []) {
        int fmedian, fsd;
        lsize = f.length;
        local = new int [lsize];

        for (int i = 0; i < lsize; i++) {
            int val = f [i];
            local [i] = val;
        }
        quicksort (local, 0, lsize - 1);
        fmedian = local [lsize / 2];

        double csum = 0.0;
        double count = (double) lsize;
        for (int i = 0; i < lsize; i++) {
            int val = f [i];
            int cdif = Math.abs (val - fmedian);
            csum += (double) (cdif * cdif);
        }
        double sdtemp = Math.sqrt (csum / count);
        fsd = (int) sdtemp;
        Point retval = new Point (fmedian, fsd);
        return retval;
    }

    Point functionrangestats (int f [], int start, int end) {
        int fmedian, fsd;
        int range = end - start;
        lsize = range;
        local = new int [lsize];

        for (int i = 0; i < lsize; i++) {
            int val = f [i + start];
            local [i] = val;
        }
        quicksort (local, 0, lsize - 1);
        fmedian = local [lsize / 2];

        double csum = 0.0;
        double count = (double) lsize;
        for (int i = 0; i < lsize; i++) {
            int val = f [i + start];
            int cdif = Math.abs (val - fmedian);
            csum += (double) (cdif * cdif);
        }
        double sdtemp = Math.sqrt (csum / count);
        fsd = (int) (sdtemp * 100.0);     // emphasize it a bit
        Point retval = new Point (fmedian, fsd);
        return retval;
    }

    Point functionrangesimple (int f [], int start, int end) {
        int average, dev;

        int sum = 0;
        int min = 10000;
        int max = 0;
        for (int i = start; i < end; i++) {
            int v = f [i];
            sum += v;
            if (v > max) {
                max = v;
            }
            if (v < min) {
                min = v;
            }
        }
        int range = end - start;
        double av = (double) sum / (double) range;
        average = (int) av;
        dev = max - min;
        Point p = new Point (dev, average);
        return p;
    }

    static void quicksort (int x [], int low, int high) {
        // Debug("quicksort "+low+" to "+high);
        int lo = low;
        int hi = high;
        if (lo >= hi) {
            return;
        }
        int mid = x [(lo + hi) / 2];
        while (lo <= hi) {
            while (lo < high && x [lo] < mid) {
                lo++;
            }
            while (hi > low && x [hi] > mid) {
                hi--;
            }
            if (lo <= hi) {
                int tx, ty;
                tx = x [lo];
                x [lo] = x [hi];
                x [hi] = tx;
                lo++;
                hi--;
            }
        }

        if (low < hi) {
            quicksort (x, low, hi);
        }
        if (lo < high) {
            quicksort (x, lo, high);
        }
    }

    static void quicksortfloat (float x  [], int low, int high) {
		// Debug("quicksort "+low+" to "+high);
		int lo = low;
		int hi = high;
		if (lo >= hi) {
			return;
		}
		float mid = x [(lo + hi) / 2];
		while (lo <= hi) {
			while (lo<high && x [lo] < mid)
				lo++;
			while (hi>low && x [hi] > mid)
				hi--;
			if (lo <= hi) {
				float tx;
				tx = x  [lo];
				x  [lo] = x  [hi];
				x  [hi] = tx;
				lo++;
				hi--;
			}
		}

		if( low < hi )
            quicksortfloat (x, low, hi );
		if( lo < high )
            quicksortfloat (x, lo, high );
    }

    static void quicksortpointy (Point p [], int low, int high) {
        // Debug("quicksort "+low+" to "+high);
        int lo = low;
        int hi = high;
        if (lo >= hi) {
            return;
        }
        int mid = p [(lo + hi) / 2].y;
        while (lo <= hi) {
            while (lo < high && p [lo].y < mid) {
                lo++;
            }
            while (hi > low && p [hi].y > mid) {
                hi--;
            }
            if (lo <= hi) {
                Point t;
                t = p [lo];
                p [lo] = p [hi];
                p [hi] = t;
                lo++;
                hi--;
            }
        }

        if (low < hi) {
            quicksortpointy (p, low, hi);
        }
        if (lo < high) {
            quicksortpointy (p, lo, high);
        }
    }

    void quicksortrectangley (Rectangle p [], int low, int high) {
        // Debug("quicksort "+low+" to "+high);
        int lo = low;
        int hi = high;
        if (lo >= hi) {
            return;
        }
        int mid = p [(lo + hi) / 2].y;
        while (lo <= hi) {
            while (lo < high && p [lo].y < mid) {
                lo++;
            }
            while (hi > low && p [hi].y > mid) {
                hi--;
            }
            if (lo <= hi) {
                Rectangle t;
                t = p [lo];
                p [lo] = p [hi];
                p [hi] = t;
                lo++;
                hi--;
            }
        }

        if (low < hi) {
            quicksortrectangley (p, low, hi);
        }
        if (lo < high) {
            quicksortrectangley (p, lo, high);
        }
    }

    // sort each row based on the 'by' coordinate
    void quicksortarray (int p [][], int by, int low, int high) {
        int lo = low;
        int hi = high;
        if (lo >= hi) {
            return;
        }
        int mid = p [(lo + hi) / 2][by];
        while (lo <= hi) {
            while (lo < high && p [lo][by] < mid) {
                lo++;
            }
            while (hi > low && p [hi][by] > mid) {
                hi--;
            }
            if (lo <= hi) {
                int t [];
                t = copyarray (p [lo]);
                p [lo] = copyarray (p [hi]);
                p [hi] = copyarray (t);
                lo++;
                hi--;
            }
        }

        if (low < hi) {
            quicksortarray (p, by, low, hi);
        }
        if (lo < high) {
            quicksortarray (p, by, lo, high);
        }
    }

    int [] copyarray (int ar []) {
        int w = ar.length;
        int val [] = new int [w];
        for (int i = 0; i < w; i++) {
            val [i] = ar [i];
        }
        return val;
    }

    void sortpoints (Point pt [], int low, int high) {
        // Debug("quicksort "+low+" to "+high);
        int lo = low;
        int hi = high;
        if (lo >= hi) {
            return;
        }
        int mid = pt [(lo + hi) / 2].x;
        int midy = pt [(lo + hi) / 2].y;
        while (lo <= hi) {
            while (lo < high && (pt [lo].x < mid || (pt [lo].x == mid && pt [lo].y < midy))) {
                lo++;
            }
            while (hi > low && (pt [hi].x > mid || (pt [lo].x == mid && pt [lo].y > midy))) {
                hi--;
            }
            if (lo <= hi) {
                Point tx, ty;
                tx = pt [lo];
                pt [lo] = pt [hi];
                pt [hi] = tx;
                lo++;
                hi--;
            }
        }

        if (low < hi) {
            sortpoints (pt, low, hi);
        }
        if (lo < high) {
            sortpoints (pt, lo, high);
        }
    }

    void tmapsort (Point p []) {
        // let us assume no value greater than 10K
        TreeMap<String, Point> map = new TreeMap<String, Point> ();
        for (int i = 0; i < p.length; i++) {
            Point q = p [i];
            int qx = q.x + 10000;
            int qy = q.y + 10000;
            String s = "" + qx + "_" + qy;
            map.put (s, q);
        }

        Set<String> keys = map.keySet ();
        int j = 0;
        for (Iterator<String> it = keys.iterator (); it.hasNext ();) {
            String key = it.next ();
            Point q = map.get (key);
            p [j++] = q;
        }
    }

    void tmapsorty (Point p []) {
        // let us assume no value greater than 10K
        TreeMap<String, Point> map = new TreeMap<String, Point> ();
        for (int i = 0; i < p.length; i++) {
            Point q = p [i];
            int qx = q.x + 10000;
            int qy = q.y + 10000;
            String s = "" + qy + "_" + qx;
            map.put (s, q);
        }

        Set<String> keys = map.keySet ();
        int j = 0;
        for (Iterator<String> it = keys.iterator (); it.hasNext ();) {
            String key = it.next ();
            Point q = map.get (key);
            p [j++] = q;
        }
    }

    int cellaverage (int top, int left, int bottom, int right, int data [][]) {
        int sum = 0;

        for (int i = top; i < bottom; i++) {
            for (int j = left; j < right; j++) {
                sum += data [i][j];
            }
        }
        double area = (double) ((bottom - top) * (right - left));
        int average = (int) ((double) sum / area);
        return average;
    }

    static double correlation (int arraysize, int X [], int Y []) {
        double sumxy = 0.0;
        double sumx = 0.0;
        double sumx2 = 0.0;
        double sumy = 0.0;
        double sumy2 = 0.0;

        double N = (double) arraysize;
        for (int i = 0; i < arraysize; i++) {
            double x = (double) X [i];
            double y = (double) Y [i];
            sumx += x;
            sumy += y;
            sumxy += (x * y);
            sumx2 += (x * x);
            sumy2 += (y * y);
        }

        // compute correlation
        // formula from http://trochim.human.cornell.edu/kb/statcorr.htm
        // (N*Sum(x*y) - Sumx*Sumy)/Sqrt(N*Sumx^2 - (Sumx)^2)*(N*Sumy^2 - (Sumy)^2))
        double numerator = N * sumxy - sumx * sumy;
        double d1 = N * sumx2 - (sumx * sumx);
        double d2 = N * sumy2 - (sumy * sumy);
        double d3 = Math.sqrt (d1 * d2);
        double r = numerator / d3;
        return r;
    }

    static int centroid (int start, int end, int w []) {
        double weighted = 0.0;
        double weight = 0.0;
        if (start == end) {
            return start;
        }
        for (int i = start; i < end; i++) {
            double x = (double) w [i];
            double y = (double) i;
            weighted += x * y;
            weight += x;
        }
        int c = (int) (weighted / weight);
        return c;
    }
}
