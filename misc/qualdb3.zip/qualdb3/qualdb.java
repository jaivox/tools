
public class qualdb {

	public static void main (String args []) {
		new qualgen ("roadqdb.g");
	}
	
};
