
import java.io.*;
import java.util.*;
import java.awt.Point;

public class qualgen {

	static String datadir = "./";
	String data;
	String datafields [];
	int nfields;
	String qual;
	String qualfields [];
	int nquals;
	TreeMap <String, int []> ranges;

	String table [][];
	int nrows;

	TreeMap <String, Integer> keymap;
	String keys [];
	int nkeys;

	String qualtable [][];

	static String ignore = "none";	// if spec says none for a field, ignore that

	stats stat;

	public qualgen (String specs) {
		stat = new stats ();
		boolean ok = getspecs (specs);
		if (!ok) return;
		ok = loadtable ();
		if (!ok) return;
		ok = getkeys ();
		if (!ok) return;
		ok = makequaltable ();
	}

	void Debug (String s) {
		System.out.println ("[qualgen]" + s);
	}

	boolean getspecs (String filename) {
		try {
			ranges = new TreeMap <String, int []> ();
			BufferedReader in = new BufferedReader (new FileReader (filename));
			String line;
			// only lines starting with numbers are allowed
			while ((line = in.readLine ()) != null) {
				if (line.trim ().length () == 0) continue;
				StringTokenizer st = new StringTokenizer (line, "\t\r\n");
				int ntokens = st.countTokens ();
				if (ntokens == 0) continue;
				String first = st.nextToken ();
				int num = getinteger (first);
				if (num == -1) continue;
				if (num == 1) {
					data = st.nextToken ();
					nfields = ntokens - 2;
					datafields = new String [nfields];
					for (int i=0; i<nfields; i++) {
						datafields [i] = st.nextToken ();
					}
				}
				else if (num == 2) {
					qual = st.nextToken ();
					nquals = ntokens - 2;	// could ignore none's here
					qualfields = new String [nquals];
					for (int i=0; i<nquals; i++) {
						qualfields [i] = st.nextToken ();
					}
				}
				else if (num > 2) {
					String field = st.nextToken ();
					int nvals = ntokens - 2;
					if (nvals != 7) {
						Debug ("Expected 7 numbers in "+line);
						return false;
					}
					int vals [] = new int [nvals];
					for (int i=0; i<nvals; i++) {
						vals [i] = getinteger (st.nextToken ());
					}
					ranges.put (field, vals);
				}
				else {
					Debug ("unexpected line ignored: "+line);
					continue;
				}
			}
			in.close ();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace ();
			return false;
		}
	}

	int getinteger (String s) {
		try {
			int val = Integer.parseInt (s);
			return val;
		}
		catch (Exception e) {
			Debug ("Integer expected: "+s);
			return -1;
		}
	}

	boolean loadtable () {
		try {
			BufferedReader in = new BufferedReader (new FileReader (datadir + data));
			ArrayList <String> rows = new ArrayList <String> ();
			String line;
			// skip first line since that is typically fields
			line = in.readLine ();
			while ((line = in.readLine ()) != null) {
				if (line.trim ().length () == 0) continue;
				rows.add (line);
			}
			in.close ();
			nrows = rows.size ();
			table = new String [nrows][nfields];
			for (int i=0; i<nrows; i++) {
				line = rows.get (i);
				StringTokenizer st = new StringTokenizer (line, ",");
				for (int j=0; j<nfields; j++) {
					table [i][j] = st.nextToken ();
				}
			}
			return true;
		}
		catch (Exception e) {
			e.printStackTrace ();
			return false;
		}
	}

	boolean getkeys () {
		try {
			// it is the first field in the data table
			String yes = "yes";
			TreeMap <String, String> map = new TreeMap <String, String> ();
			for (int i=0; i<nrows; i++) {
				String key = table [i][0];
				map.put (key, yes);
			}
			nkeys = map.size ();
			Set <String> keyset = map.keySet ();
			keys = keyset.toArray (new String [nkeys]);
			keymap = new TreeMap <String, Integer> ();
			for (int i=0; i<nkeys; i++) {
				keymap.put (keys [i], new Integer (i));
			}
			return true;
		}
		catch (Exception e) {
			e.printStackTrace ();
			return false;
		}
	}

	boolean makequaltable () {
		try {
			// number of ranges specified
			int ncols = ranges.size ();
			Set <String> keyset = ranges.keySet ();
			String cols [] = keyset.toArray (new String [ncols]);
			qualtable = new String [nkeys+1][ncols+1];
			qualtable [0][0] = qualfields [0];
			for (int i=0; i<ncols; i++) {
				qualtable [0][i+1] = cols [i];
			}
			for (int i=0; i<nkeys; i++) {
				qualtable [i+1][0] = keys [i];
			}

			for (int col=0; col<ncols; col++) {
				// find the corresponding data column
				String colname = cols [col];
				String datacol = null;
				int dcol = -1;
				for (int c=0; c<nquals; c++) {
					if (colname.equals (qualfields [c])) {
						datacol = datafields [c];
						dcol = c;
						break;
					}
				}
				if (datacol == null) {
					Debug ("No data column corresponding to qual field "+colname);
					return false;
				}

				TreeMap <String, ArrayList <String>> hold =
					new TreeMap <String, ArrayList <String>> ();

				ArrayList <String> all = new ArrayList <String> ();

				for (int i=0; i<nrows; i++) {
					String val = table [i][dcol].trim ();
					String key = table [i][0];
					ArrayList <String> vals = hold.get (key);
					if (vals == null) vals = new ArrayList <String> ();
					vals.add (val);
					hold.put (key, vals);
					all.add (val);
				}

				// we could do the above with subranges of values too
				Point mediansd [] = new Point [nkeys];

				int alln = all.size ();
				int g [] = new int [alln];
				for (int i=0; i<alln; i++) {
					g [i] = Integer.parseInt (all.get (i));
				}
				Point allp = stat.functionstats (g);

				for (int i=0; i<nkeys; i++) {
					String key = keys [i];
					ArrayList <String> vals = hold.get (key);
					int n = vals.size ();
					int f [] = new int [n];
					for (int j=0; j<n; j++) {
						f [j] = Integer.parseInt (vals.get (j));
					}
					Point p = stat.functionstats (f);
					mediansd [i] = p;
				}

				// show the values of mediansd for each
				System.out.println (colname);
				System.out.println ("all\t" + allp.x + "\t" + allp.y);
				for (int i=0; i<nkeys; i++) {
					Point p = mediansd [i];
					System.out.println (keys [i]+"\t"+p.x+"\t"+p.y);
				}

				int fudge = 0;
				int min = Integer.MAX_VALUE;
				int max = Integer.MIN_VALUE;

				for (int i=0; i<nkeys; i++) {
					Point p = mediansd [i];
					int low = p.x - fudge*p.y;
					int high = p.x + fudge*p.y;
					if (low < min) min = low;
					if (high > max) max = high;
				}


				double scale = 100.0/(max - min);
				for (int i=0; i<nkeys; i++) {
					Point p = mediansd [i];
					double m = (double)(p.x - min);
					int v = (int)(scale * m);

					qualtable [i+1][col+1] = ""+v;
				}
			}


			PrintWriter out = new PrintWriter (new FileWriter (datadir + qual));
			for (int i=0; i<nkeys+1; i++) {
				for (int j=0; j<ncols+1; j++) {
					out.print (qualtable [i][j]);
					if (j < ncols) out.print (",");
				}
				out.println ();
			}
			out.close ();

			return true;
		}
		catch (Exception e) {
			e.printStackTrace ();
			return false;
		}
	}
}
